import re 
import random
import statistics

def find_orfs(sequence, length_threshold, strand):
    start_codon = 'ATG'
    stop_codons = ['TAG', 'TAA', 'TGA']

    orfs = []
    
    for i in range(3):
        while i < len(sequence)-2:
            if sequence[i:i+3] == start_codon:
                for j in range(i+3, len(sequence)-2, 3):
                    if sequence[j:j+3] in stop_codons:
                        if j+3-i >= length_threshold:
                            # do not return orf that contains the palindrome marker
                            if 'NNNNNACTGNNNGTCANNNNN' not in sequence[i:j]:
                                orfs.append(sequence[i:j])
                        break  # stop after finding the first valid orf
            i += 3  # search for the next start codon 

    return orfs

def complement_dna_reverse(dna_sequence):
    # Define a dictionary mapping each nucleotide to its complementary base
    complement_dict = {'A': 'T', 'C': 'G', 'G': 'C', 'T': 'A'}

    # Initialize an empty string to store the reverse complemented DNA sequence
    reverse_complemented_sequence = ""

    for i in reversed(dna_sequence):
        if i in complement_dict:
            reverse_complemented_sequence +=  complement_dict[i]

    return reverse_complemented_sequence

def count_and_report_orfs(dna_sequence, length_threshold):
    orfsP = find_orfs(dna_sequence, length_threshold, '+')
    reverse_complemented_sequence = complement_dna_reverse(dna_sequence)
    orfsC = find_orfs(reverse_complemented_sequence, length_threshold, '-')
    
    orf_counts = {}

    for orf in orfsP:
        orf_len = len(orf)
        if orf_len not in orf_counts:
            orf_counts[orf_len] = 1
        else:
            orf_counts[orf_len] += 1

    for orf in orfsC:
        orf_len = len(orf)
        if orf_len not in orf_counts:
            orf_counts[orf_len] = 1
        else:
            orf_counts[orf_len] += 1

    # # Print the sorted counts
    # print("Number of ORFs of Each Length (sorted from min to max):")
    # for length, count in sorted(orf_counts.items()):
    #     print(f"Length: {length}, Count: {count}")

    # # Print the total number of ORFs
    # total_orfs = len(orfsP)+len(orfsC)
    # print(f"\nTotal Number of ORFs: {total_orfs}")

    return orf_counts, orfsP, orfsC

def estimate_threshold(dna_sequence, number_shuffles):
    thresholds = []

    for i in range(number_shuffles):
        shuffled_seq = ''.join(random.sample(dna_sequence, len(dna_sequence)))
        shuffled_orf, _, _ = count_and_report_orfs(shuffled_seq, 0)
        sorted_orf = dict(sorted(shuffled_orf.items(), reverse=True)) # sort from longest to shortest
        shuffled_num = 0
        prior_threshold = None

        # start from the longest orf length
        for length, num in sorted_orf.items():
            shuffled_num += num
            orf_counts, _, _ = count_and_report_orfs(dna_sequence, length)
            unshuffled_num = sum(orf_counts.values())

            # find the shortest length that ensures p-value <= 0.05
            if shuffled_num/(shuffled_num+unshuffled_num) <= 0.05:
                prior_threshold = length
            else:
                # if no length produces a p-value <= 0.05, just return the longest orf length
                if prior_threshold is None:
                    thresholds.append(length)
                # if the current threshold's p-value > 0.05, this means the previous threshold is the smallest that ensures p-value <= 0.05
                thresholds.append(prior_threshold)
                break

    '''   
    for i in range(number_shuffles):
        print(f"Shuffle #{i+1}: the threshold length is {thresholds[i]}")
    '''
    # convert to integer
    thresholds_int = []
    for threshold in thresholds:
        if threshold is None: 
            thresholds_int.append(0)
        else:
            thresholds_int.append(int(threshold))

    # return the median threshold of number_shuffles times 
    return round(statistics.median(thresholds_int))

'''
# Ask for input file and number of shuffles
input_file = input("Enter the path to the input file with DNA sequence: ")
#length_threshold = int(input("Enter the length threshold for ORFs: "))
number_shuffles = int(input("Enter the number of shuffle for the genome: "))

# Read DNA sequence from the input file
try:
    with open(input_file, 'r') as file:
        dna_sequence = file.read()
        dna_sequence = re.sub('>.+\n', "", dna_sequence)
        dna_sequence = dna_sequence.replace('\n',"")

except FileNotFoundError:
    print("Error: File not found.")
    exit()

#count_and_report_orfs(dna_sequence, length_threshold)
threshold = estimate_threshold(dna_sequence, number_shuffles)

threshold_int = []
for i in threshold:
    if isinstance(i, str):
        threshold_int.append(int(i))
    else:
        threshold_int = threshold
        break

# range 
print(f"The range of the {number_shuffles} thresholds is {max(threshold_int) - min(threshold_int)}.")

# min
print(f"The min of the {number_shuffles} thresholds is {min(threshold_int)}.")

# max
print(f"The max of the {number_shuffles} thresholds is {max(threshold_int)}.")

# mean
print(f"The mean of the {number_shuffles} thresholds is {sum(threshold_int)/len(threshold_int)}.")

# median 
import statistics
print(f"The median of the {number_shuffles} thresholds is {statistics.median(threshold_int)}.")

# estimate the threshold and ensure the final threshold is divisible by 3
final_threshold = statistics.median(threshold_int) 
if final_threshold % 3 == 0:
    print(f"The final threshold I chose is {int(final_threshold)}.")
else:
    print(f"The final threshold I chose is {int(final_threshold - final_threshold % 3)}.")
'''