import os

def remove_scaffold_markers(input_folder, output_folder="./"):
    os.makedirs(output_folder, exist_ok=True)

    marker = "NNNNNACTGNNNGTCANNNNN"

    for file in os.listdir(input_folder):
        if file.endswith(".fasta") or file.endswith(".fa"):
            with open(os.path.join(input_folder, file), 'r') as f:
                lines = f.readlines()

            header = lines[0]
            sequence = ''.join(line.strip() for line in lines[1:])
            cleaned_sequence = sequence.replace(marker, "")

            with open(os.path.join(output_folder, file), 'w') as out:
                out.write(header)
                for i in range(0, len(cleaned_sequence), 60):
                    out.write(cleaned_sequence[i:i+60] + "\n")

    print(f"Cleaned genomes saved in '{output_folder}'")

remove_scaffold_markers("genomes")