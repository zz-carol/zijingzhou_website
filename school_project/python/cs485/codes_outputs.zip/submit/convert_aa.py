import csv
import os

def read_codon_table(filename):
    codon_dict = {}

    with open(filename, "r") as file:
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            codon = row[0].strip()
            amino_acid = row[1].strip()
            codon_dict[codon] = amino_acid

    return codon_dict

def convert_to_aa(sequence, condon_table):
    amino_acids = []

    for i in range(0, len(sequence) - 2, 3):
        codon = sequence[i:i+3]
        aa = codon_table.get(codon, 'X') # 'X' for unknown codons
        amino_acids.append(aa)
    
    return ''.join(amino_acids)

def convert_to_aa_multi_files(input_dir, output_dir, codon_table):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for filename in os.listdir(input_dir):
        if filename.endswith(".fasta") or filename.endswith(".fa"):
            input_path = os.path.join(input_dir, filename)
            output_path = os.path.join(output_dir, filename)

            with open(input_path, "r") as infile, open(output_path, "w") as outfile:
                seq_id = None
                seq = ""

                for line in infile:
                    if line.startswith(">"):
                        if seq_id and seq:
                            converted = convert_to_aa(seq, codon_table)
                            outfile.write(f"{seq_id}\n{converted}\n")
                        seq_id = line.strip()
                        seq = ""
                    else:
                        seq += line.strip().upper()

                # Handle last sequence in file
                if seq_id and seq:
                    converted = convert_to_aa(seq, codon_table)
                    outfile.write(f"{seq_id}\n{converted}\n")

codon_table = read_codon_table('codon-table-grouped.csv')
convert_to_aa_multi_files('orfs_nucleotide', 'orfs_aa', codon_table)
