from orf import *
import os

def read_sequences(filename):

    # read sequences
    sequences = []
    with open(filename, 'r') as file:
        lines = file.readlines()
        sequence = ""
        for line in lines:
            if line.startswith('>'):
                if sequence:
                    sequences.append(sequence)
                    sequence = ""
            else:
                sequence += line.strip()
        sequences.append(sequence)

    # read sequence names
    genome_names = []
    with open(filename, "r") as file:
        for line in file:
            if line.startswith(">"):
                name = line[1:].strip().split()[0]
                genome_names.append(name)

    return sequences, genome_names

def find_orfs_multi_seq(sequences, genome_names):

    if not os.path.exists('orfs_nucleotide'):
        os.makedirs('orfs_nucleotide')
    
    index = 0

    for sequence in sequences:
        # fidn the threshold by repeating shuffle 100 times
        threshold = estimate_threshold(sequence, 100)
        print(threshold)
        '''
        _, orfs_p, orfs_c = count_and_report_orfs(sequence, threshold)

        filename = "orfs_nucleotide/" + genome_names[index] + ".fasta"

        # write the positive and conplementary orfs into a fasta file
        with open(filename, "w") as fasta_file:
            for i, orf in enumerate(orfs_p, start=1):
                header = f">{genome_names[index]}_orf_p_{i}"
                fasta_file.write(f"{header}\n{orf}\n")
            for i, orf in enumerate(orfs_c, start=1):
                header = f">{genome_names[index]}_orf_c_{i}"
                fasta_file.write(f"{header}\n{orf}\n")
        
        print(f'ORFs output created for {genome_names[index]}')

        index += 1
        '''

genomes, genome_names = read_sequences('genomes/GXS004.fasta')
find_orfs_multi_seq(genomes, genome_names)

genomes, genome_names = read_sequences('genomes/GXS005.fasta')
find_orfs_multi_seq(genomes, genome_names)

genomes, genome_names = read_sequences('genomes/GXS006.fasta')
find_orfs_multi_seq(genomes, genome_names)

genomes, genome_names = read_sequences('genomes/GXS013.fasta')
find_orfs_multi_seq(genomes, genome_names)

genomes, genome_names = read_sequences('genomes/GXS015.fasta')
find_orfs_multi_seq(genomes, genome_names)
